<?php
require_once('config.php');
require_once('includes/constant.php');
require_once('includes/app_start.php');
require_once('includes/functions.php');
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);