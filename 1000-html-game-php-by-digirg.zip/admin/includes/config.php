<?php

require '../config.php';
    // $host_name = 'localhost';
    // $sql_db_user = 'root';
    // $sql_db_pass = '';
    // $sql_db_name = 'zontal';

    // $con = mysqli_connect($host_name, $sql_db_user,  $sql_db_pass, $sql_db_name);

    // $site_url = "http://localhost/Zontal/";
?>